-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2022 at 04:44 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrms`
--

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `ID` int(11) NOT NULL,
  `Requester_ID` varchar(255) DEFAULT NULL,
  `Requester_Name` varchar(255) DEFAULT NULL,
  `Request_Type` varchar(255) DEFAULT NULL,
  `From_Date` date DEFAULT NULL,
  `To_Date` date DEFAULT NULL,
  `From_Time` time DEFAULT NULL,
  `To_Time` time DEFAULT NULL,
  `Request_Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`ID`, `Requester_ID`, `Requester_Name`, `Request_Type`, `From_Date`, `To_Date`, `From_Time`, `To_Time`, `Request_Status`) VALUES
(1, '201710036', 'Wesam Daabes', 'Vacation', '2021-12-25', '2021-12-25', NULL, NULL, 'Approve'),
(2, '201710036', 'Wesam Daabes', 'Vacation', '2021-12-25', '2021-12-25', NULL, NULL, 'Deny'),
(3, '201710036', 'Wesam Daabes', 'Leave', '2021-12-25', NULL, '14:21:00', '05:15:00', 'Deny'),
(4, '201710036', 'Wesam Daabes', 'Vacation', '2021-12-26', '2021-12-31', NULL, NULL, 'Deny'),
(5, '201710036', 'Wesam Daabes', 'Vacation', '2021-12-25', '2021-12-25', NULL, NULL, 'Deny'),
(6, '201710036', 'Wesam Daabes', 'Vacation', '2021-12-30', '2021-12-30', NULL, NULL, 'Approve'),
(8, '201810264', 'Fahed Khalil', 'Leave', '2022-01-12', NULL, '08:53:00', '18:06:00', 'Deny'),
(9, '201710036', 'Wesam Daabes', 'Vacation', '2022-01-12', '2022-01-12', NULL, NULL, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Employee_ID` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Access` varchar(255) DEFAULT NULL,
  `First_Name` varchar(255) DEFAULT NULL,
  `Last_Name` varchar(255) DEFAULT NULL,
  `Employee_Salary` float(255,2) DEFAULT NULL,
  `Employee_Salary_Currency` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Employee_ID`, `Password`, `Access`, `First_Name`, `Last_Name`, `Employee_Salary`, `Employee_Salary_Currency`) VALUES
(1, '0', '12345', 'Admin', 'Muhammad', 'Taye', 2000.00, 'USD'),
(2, '1', '12345', 'Admin', 'Samer', 'Hannah', 2000.00, 'USD'),
(3, '201710036', '12345', 'User', 'Wesam', 'Daabes', 600.00, 'JOD'),
(5, '201810264', '12345', 'User', 'Fahed', 'Khalil', 150.00, 'JOD'),
(6, '201710115', '12345', 'User', 'Malik', 'Qawasmeh', 100.00, 'JOD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`ID`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
